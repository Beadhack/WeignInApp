package Java;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author prtaylor
 */
@WebServlet(urlPatterns = {"/DentistLogionServlet"})
public class demoServlet extends HttpServlet {
 
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

//pull id and pw from login html page
        String userNM = request.getParameter("userName");
        String userPW = request.getParameter("password");
 
//>>> test to see if user is Dentist,     
        if (userNM.startsWith("D")) {

                //loading d1 object from database
                        Dentist d1 = new Dentist();
                        d1.selectDB(userNM);
                        d1.display();

                //put object into session
                         HttpSession session;
                         session = request.getSession();
                         session.setAttribute("d1",d1);
                         System.out.println("Dentist object added to session");

                //verifyLogin() checks entered pw with pw in database, returns boolean
                        if (  d1.verifyLogin(userNM, userPW)  ) {
                                    System.out.println("Dentist login is good - YAY!");
                                    RequestDispatcher rd = request.getRequestDispatcher("/DentistHomePage.jsp");
                                    rd.forward(request, response);
                        }else{
                                    System.out.println("Dentist login is NOT good.  BOO!");
                                    request.getRequestDispatcher("/LoginError.jsp").forward(request,response);
                        }          
         }//close if test for "D"
        
//>>> else case is if login is Not D (i.e.  Patient )    
        else {            
                //loading p1 object from database
                        Patient p1 = new Patient();
                        p1.selectDB(userNM);
                        p1.display();

                //put p1 object into session
                         HttpSession session;
                         session = request.getSession();
                         session.setAttribute("p1",p1);
                         System.out.println("Patient object added to session");

                //verifyLogin() checks entered pw with pw in database, returns boolean
                        if (  p1.verifyLogin(userNM, userPW)  ) {
                            System.out.println("Patient login is good - YAY!");
                            RequestDispatcher rd = request.getRequestDispatcher("/PatientHomePage.jsp");
                            rd.forward(request, response);
                        }else{
                            System.out.println("Patient login is NOT good.  BOO!");
                            request.getRequestDispatcher("/LoginError.jsp").forward(request,response);
                         } //end else for verify Patient id/pw
                        
         } //ends else test for "D"               
    }//ends method processRequest()

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
