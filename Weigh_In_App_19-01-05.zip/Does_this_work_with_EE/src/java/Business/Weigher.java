/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author prtaylor
 */
public class Weigher {
    
    Connection con;
    Statement stmt;
    
    //atributes
    String userID;
    String pw;
    String date;
    double weight;

    public String getUserID() {
        return userID;
    }

    public String getPw() {
        return pw;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    

    public Weigher() {
    }

    public Weigher(String userID, String pw, String date, double weight) {
        this.userID = userID;
        this.pw = pw;
        this.date = date;
        this.weight = weight;
    }
    
//------------- userExists ------------------------------------------    
    public boolean userExists(String userID){
        boolean flag = false;
    
        openConnection();
        
        try {

//                    String url  = "jdbc:mysql://localhost:3306/weight_tracker"; 
//                    String user = "reneeTestUser";
//                    String pass = "mypass"; 
//
//                    con = DriverManager.getConnection(url,user,pass); 
//                    stmt = con.createStatement();
//                    System.out.println("Database connected");

            String sql = "SELECT count(*) FROM users WHERE id ='"+userID+"';";
            System.out.println("sql query is: "+sql);
        
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            
            if (rs.getInt(1)==1){
                flag=true;
            }
           
        } catch (SQLException ex) {
            System.out.println(ex);
        } catch (Exception ex1) {
            System.out.println(ex1);
        }
        
        return flag;
    }//end userExists
    
//------------- selectDB ------------------------------------------    
   
    
//------------- openConnection ------------------------------------------    
    public void openConnection(){
        
        String url  = "jdbc:mysql://localhost:3306/weight_tracker"; 
        String user = "reneeTestUser";
        String pass = "mypass"; 
                                                  
        try{
            
            con = DriverManager.getConnection(url,user,pass); 
            stmt = con.createStatement();
            System.out.println("Database connected");
           
        }catch(SQLException ex){
            System.out.println("Connection Failed");
            System.out.println(ex);
        }
     
    }//end openConnection()
    
    
//------------- Main - where stuff gets tested  -----------------------------
    public static void main(String args[]){
        
        Weigher w1 = new Weigher();

        boolean flag = w1.userExists(w1.getUserID());
        System.out.println("user prtaylor exists? " +flag );

//        w1.openConnection();
    }
    
}//end class Weigher()
